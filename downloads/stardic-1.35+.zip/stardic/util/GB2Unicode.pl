#!/usr/local/bin/perl5

my $Version;
$Version = "0.1.0829";

$count=0;

open (SOURCEFILE, "GB2312.TXT") or die "cannot open sourcefile";
open (TARGETFILE, ">" . "GB2Uni.txt") or die "cannot open targetfile";

while ( $line = <SOURCEFILE> )
{
    if ( $line =~ /^0x(.{4})\t0x(.{4}).*/ )
    {
        $CodeTable{$1}=$2;
    }
}

foreach $key (sort keys %CodeTable)
{
    $count=$count+1;
}
printf (TARGETFILE "#%d\n",$count);

foreach $key (sort keys %CodeTable)
{
    printf (TARGETFILE "%s %s\n",$key,$CodeTable{"$key"}) ;
}

close (SOURCEFILE);
close (TARGETFILE);

1
