#include <stdio.h>

typedef unsigned short WORD;

int main(int argc,char **argv)
{
    FILE *input, *output;
    char Buffer[256],stringa[256],stringb[256];
    int icount;
    WORD count;
    WORD a,b;
    if (!(input = fopen("Uni2BIG5.txt", "r")))
    {
        fprintf(stderr,"Input File not found\r\n");
        return -2;
    }
    /* Open output file */
    if (!(output = fopen("Uni2BIG5.tab", "wb")))
    {
        fprintf(stderr,"Unable to open outfile\r\n");
        fclose(input);
        return -3;
    }
    //get count
    fgets(Buffer,100,input);
    sscanf(Buffer+1,"%d",&icount);
    count=(WORD)icount;
    fwrite(&count,sizeof(count),1,output);
    
    while (fgets(Buffer,255,input))
    {
        if (sscanf(Buffer,"%s %s",stringa,stringb)!=2)
        {
            fprintf(stderr,"error when read data\r\n");
            return -4;
        }
        a=(WORD)(strtol(stringa,NULL,16)+0);
        b=(WORD)(strtol(stringb,NULL,16)+0);
        fwrite(&a,sizeof(a),1,output);
        fwrite(&b,sizeof(b),1,output);
    }
    fclose(input);
    fclose(output);
}
