char * BUILD_DATE_S = __TIME__ " " __DATE__;
