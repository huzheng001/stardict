/*
** A. J. Fountain,
** Imperial Software Technology,
** 120 Hawthorne Avenue,
** Suite 101,
** Palo Alto,
** CA 94301
**
** Telephone: (650) 688-0200
** Fax:       (650) 688-1054
**
** Imperial Software Technology (IST),
** Kings Court,
** 185 Kings Road,
** Reading,
** Berkshire,
** United Kingdom RG1 4EX.
**
** Telephone: +44 189 587055
** Fax:       +44 189 589005
**
** http://www.ist-inc.com
** email: af@ist-inc.com
*/

/*
** sccsid[] = {"%Z%%Q%%M%	%I%"} -- %E%
*/

#ifndef   _XErrorHandler_h
#define   _XErrorHandler_h

#include <X11/Intrinsic.h>

#ifdef    _cplusplus
extern "C" {
#endif /* _cplusplus */

/*
** Types.
*/

#ifndef   _NO_PROTO
typedef void (*XApplicationSaveHandler)(XtPointer) ;
#else  /* _NO_PROTO */
typedef void (*XApplicationSaveHandler)() ;
#endif /* _NO_PROTO */

/*
** Public Routines.
*/

#ifndef   _NO_PROTO
extern void InitializeErrorHandlers(XtAppContext, XApplicationSaveHandler, XtPointer) ;
#else  /* _NO_PROTO */
extern void InitializeErrorHandlers() ;
#endif /* _NO_PROTO */

#ifdef    _cplusplus
}
#endif /* _cplusplus */

#endif /* _XErrorHandler_h */
