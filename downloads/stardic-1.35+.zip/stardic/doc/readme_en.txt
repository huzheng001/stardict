			stardic 1.31
-----------------------------------------------------------------
stardic version 1.31
writer: Ma Su An
email : msa@wri.com.cn
copyright: Ma Su An
protocol : GPL
-----------------------------------------------------------------

1.Package content
-----------------------------------------------------------------
	* source code,image files;
	* Chinese fonts;
	* word library;

2.Functions
-----------------------------------------------------------------
	* an Englisth-Chinese dictionary software for Unix;
	* about 50000 words,some have phonetic symbol;
	* rule match;
	* fetch word from screen;
	* no Chinese envirenment needed;

3.Developping group
-----------------------------------------------------------------
Ma Su An (msa@wri.com.cn)

4.Usage
-----------------------------------------------------------------
Please install first, then press "help" button to read 
help information.

