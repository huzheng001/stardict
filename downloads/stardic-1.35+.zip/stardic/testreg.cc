#include <stdio.h>
#include <string.h>
#include "regdef.h"
int main(int argc,char** argv)
{
	if(argc<2)
	{
		printf("Usage:%s RuleString\n",argv[0]);
		return(1);
	}

	MSARegExp reg(argv[1]);
	if(reg.iStatus()!=MSARegExp::OK)
	{
		printf("rule error:%s !\n",argv[1]);
		return(1);
	}
	else
	{
		printf("use rule: %s !\n",argv[1]);
	}

        for(;;)
        {
                char linebuf[1000];
                scanf("%s",linebuf);

                if(!strcmp("quit",linebuf)) return(0);

		char sMarchWord[100];
                if(reg.bIsMarch(linebuf,sMarchWord,100))
                {
                        printf("March %s !\n",sMarchWord);
                }

                if(reg.bIsEntireMarch(linebuf))
                {
                        printf("Entire March !\n",sMarchWord);
                }

                printf("end!\n");
        }
}

