/*
    writer : Opera Wang
    E-Mail : wangvisual AT sohu.com
    License: GPL
*/

/* filename: getini.h */

#ifndef GETINI_H
#define GETINI_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pwd.h>

#ifdef __cplusplus
extern "C" {
#endif

void GetIniFileName( const char * BaseFileName, char * FileName );
char GetStringFromIni( const char * FileName, const char * Name, char * String, const char * DefaultString);
void SaveStringToIni( const char * FileName, const char * Name, const char * String);
int  GetIntFromIni( const char * FileName, const char * Name, int * Value, const int DefaultInt);
void SaveIntToIni( const char * FileName, const char * Name, const int Value);

#ifdef	__cplusplus
}
#endif

#endif
