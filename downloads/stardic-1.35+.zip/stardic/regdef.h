/*
	writer	: Ma Su An
	E-Mail	: msa@wri.com.cn
	
	Copyright by Ma Su An.
	All rights reserved.
	Permission to use ,copy,modify,and distribute this software for
	individual use and without fee is granted with that condition:

    	Every copy of this software must have the writer's name displayed 
	on the top label.
*/

// filename: regdef.h
// msa 1999.1

#ifndef REGDEF_H
#define REGDEF_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <regex.h>

class MSARegExp
{
public:
	enum { OK,ILLEGAL,TOOLONG };
private:
	regex_t reg_;
	int iStatus_;
public:
	MSARegExp(char* sRule);
	~MSARegExp();
	int bIsMatch(const char* sWord,int& iFrom,int& iLength) const;
	int bIsMatch(const char* sWord,char* sBuff,int iBuffLen) const;
	int bIsEntireMatch(const char* sWord) const;
	inline int iStatus() const { return(iStatus_); } ;
};

#endif
