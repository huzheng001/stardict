/*
	writer	: Ma Su An
	E-Mail	: msa@wri.com.cn
	
	Copyright by Ma Su An.
	All rights reserved.
	Permission to use ,copy,modify,and distribute this software for
	individual use and without fee is granted with that condition:

    	Every copy of this software must have the writer's name displayed 
	on the top label.
*/

// filename: def.h
// msa 1999.1

#ifndef DEF_H
#define DEF_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef True
#define True	1
#endif

#ifndef False
#define False	0
#endif

#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif

#ifndef NULL
#define NULL	0
#endif

#endif
