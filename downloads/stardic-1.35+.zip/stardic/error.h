/*
	writer	: Ma Su An
	E-Mail	: msa@wri.com.cn
	
	Copyright by Ma Su An.
	All rights reserved.
	Permission to use ,copy,modify,and distribute this software for
	individual use and without fee is granted with that condition:

    	Every copy of this software must have the writer's name displayed 
	on the top label.
*/

// filename: error.h
// msa 1999.1

#ifndef _error_h
#define _error_h

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <errno.h>
#define SUCCESS		0
#define BADIMAGEFILE   	200    /* image file err or not an image file */
#define BADEXEFILE     	201    /* can not execute a file */
#define BITMAPERR      	203    /* can't read bitmap file or not a bitmap file */
#define NOTGIF        	204    /* Not a gif file */
#define SPECIALFILE    	205    /* Is a special gif file */
#define EOIERR         	206    /* gif file lost its  end_of_image code */
#define NOTXPM         	207    /* Not a xpm file */
#define DBERR          	208    /* DataBase error */
#define DBWARN         	209    /* DataBase warning */
#define NETERR		210    /* net error */
#define MTERR		211    /* multithread error */
#define NOROW		212    /* no row found in database */
#define JKHOSTERR	213    /* can not find JKHOST  */
#define NOCONFIG	214    /* can not find board's config data */
#define CONFIGLENERR	215    /* board's config length error */

extern char sErrorMessage[]; // error message.
#endif

/********************* END *********************/
